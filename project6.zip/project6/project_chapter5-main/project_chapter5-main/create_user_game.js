const { user_game } = require('./models')
user_game.create({
email: 'iskandar.maulana.putera@gmail.com',
password: '123456',
username: 'kandar1989',
nama: 'Iskandar Maulana Putera',
gender: 'male'
})
.then(user_game => {
console.log(user_game)
})