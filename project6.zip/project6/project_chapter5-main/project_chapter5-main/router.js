var express = require("express");
const { render } = require("express/lib/response");
var router = express.Router();
const users = require("./users.json");
const { user_game } = require('./models');

// router.post("/login", (req, res) => {
//   user_game.findOne({()
//   .then(user_game => console.log(user_game))
//   // const user = users.find((item) => item.username === req.body.username && item.password === req.body.password);
  
//     if (user) {
//     //   req.session.user = req.body.email;
//       res.redirect("/home");
//     } else {
//       res.end("Invalid Email or Password");
//     }
//   });

router.post("/register", (req, res) => {
const { username,password,email,nama} = req.body;
        
user_game.create({
email : email,
password: password ,
username: username,
nama: nama
})
.then(user_game => {
  res.render("index")
})
.catch(err => {
  res.status(422).json("Can't create database")
})
})


router.post("/update", (req, res) => {
  const { username,password,email,nama} = req.body;
  const query = {
    where: { username: req.body.username }
    }
    user_game.update({
        email: email,
        password: password,
        username: username,
        nama: nama,
       }, query)
    .then(user_game => {
    res.render("index")
    console.log("Data berhasil diupdate")
    
    })
    .catch(err => {
    console.error("Gagal mengupdate Data!")
    })
  })
  

  router.post("/delete", (req, res) => {
    const { username} = req.body;
    user_game.destroy({
      where: {
      username: username
      }
      })
      .then(() => console.log("data sudah dihapus"))
    .then(user_game => {
      res.render("index")
    })
    .catch(err => {
      res.status(422).json("Can't delete database")
    })
    })


router.get("/logout", (req, res) => {
    req.session.destroy(function (err) {
      if (err) {
        console.log(err);
        res.send("Error");
      } else {
        res.render("login");
      }
    });
  });



  module.exports = router;