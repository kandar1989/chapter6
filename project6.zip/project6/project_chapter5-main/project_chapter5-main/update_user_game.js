const { user_game } = require('./models')
// Kita lakukan query terhadap artikel
// Artikel tersebut memiliki id yang bernilai 1
const query = {
where: { username: 1 }
}
user_game.update({
    email: 'iskandar.maulana.putera@gmail.com',
    password: '123456',
    username: 'kandar1989',
    nama: 'Iskandar Maulana Putera',
   
}, query)
.then(() => {
console.log("Data berhasil diupdate")
process.exit()
})
.catch(err => {
console.error("Gagal mengupdate Data!")
})