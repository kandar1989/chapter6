const { user_game_history } = require('./models')
user_game_history.create({

username: 'kandar1989',
waktu: '60 menit',
skor:'1280'
})
.then(user_game_history => {
console.log(user_game_history)
})