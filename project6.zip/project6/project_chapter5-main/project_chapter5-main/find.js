const { user_game } = require('./models')

user_game.findAll()
    .then(user_game => console.log(user_game))
    
  