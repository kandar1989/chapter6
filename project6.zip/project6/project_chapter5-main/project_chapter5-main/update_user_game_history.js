const { user_game_history } = require('./models')
// Kita lakukan query terhadap artikel
// Artikel tersebut memiliki id yang bernilai 1
const query = {
where: { id: 1 }
}
user_game_history.update({
    username: 'kandar1989',
    waktu: '120 menit',
    skor:'1280'
}, query)
.then(() => {
console.log("Data berhasil diupdate")
process.exit()
})
.catch(err => {
console.error("Gagal mengupdate Data!")
})