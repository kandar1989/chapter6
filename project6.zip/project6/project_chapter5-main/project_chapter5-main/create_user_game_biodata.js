const { user_game_biodata } = require('./models')
user_game_biodata.create({
email: 'iskandar.maulana.putera@gmail.com',
password: '123456',
nama: 'Iskandar Maulana Putera',
alamat:'Medan'
})
.then(user_game_biodata => {
console.log(user_game_biodata)
})